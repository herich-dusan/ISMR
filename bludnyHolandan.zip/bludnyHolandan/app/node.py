class Node:

    def __init__(self, pos_x, pos_y, is_occupied, neighbors=None):
        raise NotImplemented

    def set_occupancy(self, is_occupied):
        raise NotImplemented

    def set_neighbors(self, neighbors):
        raise NotImplemented

    def add_neighbor(self, neighbor):
        raise NotImplemented

    def remove_neighbor(self, neighbor):
        raise NotImplemented

    def get_distance(self, node):
        raise NotImplemented
