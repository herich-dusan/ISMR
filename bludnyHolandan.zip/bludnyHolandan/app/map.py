class Map:

    def __init__(self, size):
        raise NotImplemented

    def find_neighbors(self, node):
        raise NotImplemented

    def get_nodes(self):
        raise NotImplemented
